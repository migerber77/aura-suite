# AuraProxy

Ein Eingang für alle eure Dienste: leitet Domains an interne Adressen weiter und besorgt automatisch
Let's-Encrypt-Zertifikate.

## Voraussetzungen

- Die Ports **80 und 443** müssen auf dem Server frei sein und aus dem Internet erreichbar
  (Router/Firewall auf diesen Server weiterleiten). Port 80 bleibt immer für die Zertifikatsprüfung offen.
- Läuft auf demselben Server schon ein anderer Dienst auf 80/443 (z.B. ein früherer Caddy von AuraChat),
  muss er diese Ports zuerst freigeben.

## Einrichtung

```bash
cp .env.example .env
```

`.env` öffnen und den Wert ausfüllen (Anleitung steht direkt in der Datei).

```bash
docker compose up -d
```

Verwaltungsoberfläche: `http://<Server-IP>:3500` (**nicht öffentlich freigeben**).
Erste Anmeldung: Benutzername `admin`, Passwort `admin` (bitte sofort ändern).

## Domain einrichten

1. Beim Domain-Anbieter den DNS-Eintrag der Domain auf eure öffentliche Adresse setzen.
2. In AuraProxy "Neue Domain-Zuordnung": Domain, externer Port (443 oder ein vorbereiteter Zusatzport),
   interne Ziel-Adresse und Ziel-Port eintragen. Das Zertifikat wird automatisch geholt.
3. Unter "Zertifikate" sieht man alle aktiven Zertifikate. Dort lassen sich automatisch ausgestellte Zertifikate
   löschen, und pro Domain kann ein eigenes Zertifikat hochgeladen werden.

Zusätzliche externe Ports (vorbereitet: 8090, 8092–8095, 8097–8099) lassen sich in `docker-compose.yml`
unter `EXTRA_PORTS` und bei `caddy` ändern. Danach neu starten.

## Aktualisieren

```bash
docker compose pull
docker compose up -d
```

## Zentrale Anmeldung (optional)

Admin Panel → Einstellungen → AuraDirect: Adresse und Dienst-Schlüssel eintragen und "Verbindung testen".
In AuraDirect bei der Person das Häkchen "AuraProxy" setzen. Das Konto `admin` bleibt als Notzugang immer lokal.

## Lizenz

AuraProxy ist kostenlos bis 4 Konten oder sobald mindestens zwei Aura-Anwendungen (z.B. AuraChat und
AuraPlan) verbunden sind. Eigenständig genutzt kostet es CHF 15.– pro Installation und Monat.
Lizenzschlüssel und Fragen: info@gerber-backoffice-solutions.com

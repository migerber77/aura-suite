# AuraChat am Telefon

Ruft eine Nebenstelle an, spricht mit Aura, bekommt gesprochene Antworten zurück - genau
wie ein Gespräch, nur dass am anderen Ende AuraChat antwortet statt eine Person.

**Premium-Feature:** Braucht das lizenzierte Feature "Telefonanlagen-Anbindung"
(`telephony`) zusätzlich zum TTS/STT-Feature - ohne das antworten `/api/v1/stt` und
`/api/v1/tts` mit einer 402-Fehlermeldung.

Zwei Varianten liegen bei, je nachdem, welche Telefonanlage ihr nutzt:

| Datei | Für |
|---|---|
| `aura-bridge.py` + `extensions.conf.beispiel` | Asterisk / FreePBX |
| `aura-bridge-3cx.js` | 3CX |

**Zum Vertrauensgrad, ganz offen:** Die Asterisk-Variante folgt dem AGI-Protokoll, das
seit vielen Jahren stabil und gut dokumentiert ist - das Grundgerüst sollte zuverlässig
funktionieren. Die 3CX-Variante nutzt deren Call-Flow-Designer-API, die sich zwischen
3CX-Versionen unterscheidet und mir weniger vertraut ist als Asterisk - dort sind
mehrere Stellen mit `// PRÜFEN:` markiert, die gegen die aktuelle 3CX-Dokumentation
eurer konkreten Version geprüft werden sollten, bevor es produktiv läuft.

## Voraussetzungen

- Eine SIP-Telefonanlage: **Asterisk** direkt, oder **FreePBX** (baut auf Asterisk auf,
  gleiche Anleitung gilt). 3CX und andere PBX-Systeme funktionieren nach einem ähnlichen
  Prinzip, das AGI-Skript selbst ist aber speziell für Asterisk/FreePBX geschrieben.
- IP-Telefone oder ein SIP-Softphone, das an dieser Anlage angemeldet ist (praktisch jedes
  gängige Modell - Yealink, Cisco, Grandstream, etc. - funktioniert, solange es SIP spricht)
- Das AuraChat-TTS/STT-Premium-Feature muss lizenziert und konfiguriert sein

## 1. AuraChat vorbereiten

Admin Panel → API → einen neuen API-Schlüssel erzeugen, Namen z.B. "Telefonanlage" geben.
Diesen Schlüssel gleich griffbereit halten.

## 2a. Asterisk / FreePBX

```bash
pip install requests --break-system-packages
apt install ffmpeg          # Debian/Ubuntu - für andere Distributionen entsprechend anpassen

cp aura-bridge.py /var/lib/asterisk/agi-bin/aura-bridge.py
chmod +x /var/lib/asterisk/agi-bin/aura-bridge.py
```

In `aura-bridge.py` ganz oben zwei Zeilen anpassen:

```python
AURACHAT_BASE_URL = "https://aurachat.gerber-backoffice-solutions.com"  # eure echte Adresse
AURACHAT_API_KEY = "der-vorhin-erzeugte-schluessel"
```

In `/etc/asterisk/extensions.conf` den Ausschnitt aus `extensions.conf.beispiel` ergänzen
(Nebenstellennummer und Kontextname `[from-internal]` an eure bestehende Anlage anpassen -
FreePBX z.B. nutzt oft einen anderen Kontextnamen, dort am einfachsten über die
Weboberfläche eine "Custom Destination" auf `agi(aura-bridge.py)` anlegen statt die Datei
direkt zu bearbeiten).

```bash
asterisk -rx "dialplan reload"
```

## 2b. 3CX

1. 3CX Admin Console → Call Flow Designer → neues Skript anlegen
2. Inhalt von `aura-bridge-3cx.js` einfügen
3. Ganz oben `AURACHAT_BASE_URL` und `AURACHAT_API_KEY` eintragen
4. Die mit `// PRÜFEN:` markierten Stellen gegen eure 3CX-Version/-Dokumentation
   verifizieren (siehe Hinweis oben) und bei Bedarf anpassen
5. Das Skript einer Nebenstelle oder Eingangsregel zuweisen

## 3. Testen

Die eingerichtete Nebenstelle von einem angemeldeten Telefon aus anrufen. Aura sollte sich
mit der Begrüssung melden, danach abwechselnd zuhören und antworten.

## Wie es funktioniert

```
Anruf kommt rein
      │
      ▼
Asterisk startet aura-bridge.py für diesen Anruf
      │
      ▼
Begrüssung abspielen (einmal per TTS erzeugt, danach wiederverwendet)
      │
      ▼
┌─────────────────────────────────────────────┐
│  Zuhören (mit automatischer Stille-Erkennung) │
│         │                                     │
│         ▼                                     │
│  An AuraChats Spracherkennung senden          │
│         │                                     │
│         ▼                                     │
│  Text an AuraChats Chat-API senden            │
│         │                                     │
│         ▼                                     │
│  Antwort per TTS in Sprache umwandeln         │
│         │                                     │
│         ▼                                     │
│  Abspielen                                    │
└─────────────────────────────────────────────┘
      │ (wiederholt sich, bis aufgelegt wird,
      │  ein Abschiedswort fällt, oder die
      │  Rundenzahl-Obergrenze erreicht ist)
      ▼
Verabschiedung, auflegen
```

## Grenzen, die man kennen sollte

- **Kein "Hey Aura" am Telefon nötig** - sobald man durchgestellt ist, hört Aura einfach zu
- **Eine Runde dauert spürbar länger** als ein normales Telefongespräch mit einem Menschen -
  Aufnahme, Erkennung, KI-Antwort, Sprachausgabe brauchen zusammen ein paar Sekunden
- **Kein Bezug zum normalen Chatverlauf** - dieses Gespräch läuft über die einfache
  zustandslose Chat-API (`/api/v1/chat`), nicht über einen bestimmten Benutzer-Account,
  also ohne persönliches Gedächtnis oder Persönlichkeitseinstellungen dieses Kontos
- **Externe Anrufe von aussen** brauchen zusätzlich einen SIP-Trunk bei einem
  VoIP-Anbieter oder eine bestehende Amtsleitung, die auf die Nebenstelle geroutet wird -
  das ist Sache eurer Telefonanlagen-Konfiguration, nicht Teil dieser Anleitung

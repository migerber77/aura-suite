#!/usr/bin/env python3
"""
AuraChat <-> Telefonanlage: Asterisk-AGI-Brücke

Läuft AUF DEM ASTERISK-SERVER (nicht in Docker/AuraChat selbst) und wird von Asterisk
für jeden eingehenden Anruf auf die entsprechende Nebenstelle einmal gestartet (siehe
extensions.conf.beispiel daneben). Nutzt AuraChats offene API (API-Schlüssel, siehe
Admin Panel -> API) für Spracherkennung, Chat und Sprachausgabe.

Ablauf pro Anruf:
    Abheben -> Begrüssung abspielen -> [Zuhören -> STT -> Chat -> TTS -> Abspielen] im
    Kreis, bis aufgelegt wird oder die maximale Rundenzahl erreicht ist.

Einrichtung auf dem Asterisk-Server
------------------------------------
1. Python-Pakete installieren:
       pip install requests --break-system-packages
2. ffmpeg installieren (wandelt AuraChats Sprachausgabe ins telefonietaugliche Format um):
       apt install ffmpeg          # Debian/Ubuntu
       # oder: yum install ffmpeg  # RHEL/CentOS
3. Diese Datei nach /var/lib/asterisk/agi-bin/aura-bridge.py kopieren, ausführbar machen:
       chmod +x /var/lib/asterisk/agi-bin/aura-bridge.py
4. Unten AURACHAT_BASE_URL und AURACHAT_API_KEY eintragen (Schlüssel: AuraChat Admin
   Panel -> API -> "API-Schlüssel erzeugen").
5. In extensions.conf die Nebenstelle einrichten, siehe extensions.conf.beispiel daneben.
6. Asterisk neu laden: asterisk -rx "dialplan reload"

Danach: die eingerichtete Nebenstelle anrufen (intern oder über eine an sie
weitergeleitete externe Nummer) - Aura meldet sich.
"""

import sys
import subprocess
import tempfile
import os
import time
import requests

# --- Anpassen ---
AURACHAT_BASE_URL = "https://aurachat.gerber-backoffice-solutions.com"  # eure AuraChat-Adresse
AURACHAT_API_KEY = "HIER-EUREN-API-SCHLUESSEL-EINTRAGEN"
MAX_TURNS = 12                # maximale Anzahl Frage-Antwort-Runden pro Anruf (Sicherheitsgrenze)
RECORD_MAX_SECONDS = 15        # längste erlaubte Aufnahme pro Runde
RECORD_SILENCE_SECONDS = 2     # so viel Stille beendet die Aufnahme automatisch
GREETING_TEXT = "Hallo, hier ist Aura. Wie kann ich dir helfen?"
GOODBYE_TEXT = "Auf Wiederhören!"


class AGI:
    """Minimale Asterisk-AGI-Anbindung - liest die Startvariablen, kann Befehle senden."""

    def __init__(self):
        self.env = {}
        while True:
            line = sys.stdin.readline().strip()
            if not line:
                break
            key, _, value = line.partition(':')
            self.env[key.strip()] = value.strip()

    def command(self, cmd):
        sys.stdout.write(cmd + "\n")
        sys.stdout.flush()
        return sys.stdin.readline().strip()

    def answer(self):
        self.command("ANSWER")

    def hangup(self):
        self.command("HANGUP")

    def verbose(self, msg, level=1):
        self.command(f'VERBOSE "{msg}" {level}')

    def stream_file(self, filename_no_ext, escape_digits=""):
        """Spielt eine Audiodatei ab (ohne Dateiendung angeben, Asterisk findet sie selbst)."""
        self.command(f'STREAM FILE {filename_no_ext} "{escape_digits}"')

    def record_file(self, filename_no_ext, fmt="wav", max_seconds=15, silence_seconds=2):
        """Nimmt die Stimme der anrufenden Person auf, bis Stille erkannt wird oder das
        Zeitlimit erreicht ist."""
        timeout_ms = max_seconds * 1000
        self.command(
            f'RECORD FILE {filename_no_ext} {fmt} "#" {timeout_ms} 0 BEEP s={silence_seconds}'
        )


def convert_for_telephony(input_bytes, out_path):
    """Wandelt AuraChats TTS-Ausgabe (meist MP3, höhere Samplerate) ins 8kHz-Mono-WAV um,
    das Asterisk zuverlässig abspielen kann."""
    with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as tmp_in:
        tmp_in.write(input_bytes)
        tmp_in_path = tmp_in.name
    try:
        subprocess.run(
            ["ffmpeg", "-y", "-i", tmp_in_path, "-ar", "8000", "-ac", "1", "-acodec", "pcm_s16le", out_path],
            check=True, capture_output=True, timeout=20
        )
    finally:
        os.unlink(tmp_in_path)


def speak(agi, text, cache_key=None):
    """Holt Sprachausgabe von AuraChat, wandelt sie um und spielt sie ab.
    cache_key: falls gesetzt (z.B. für die immer gleiche Begrüssung), wird die Datei
    nach dem ersten Mal wiederverwendet statt jedes Mal neu erzeugt zu werden."""
    out_path = f"/tmp/aura_{cache_key or int(time.time() * 1000)}.wav"
    if not (cache_key and os.path.exists(out_path)):
        resp = requests.post(
            f"{AURACHAT_BASE_URL}/api/v1/tts",
            headers={"X-API-Key": AURACHAT_API_KEY, "Content-Type": "application/json"},
            json={"text": text}, timeout=30
        )
        resp.raise_for_status()
        convert_for_telephony(resp.content, out_path)
    agi.stream_file(out_path.replace(".wav", ""))


def listen_and_understand(agi):
    """Nimmt eine Äusserung auf und schickt sie an AuraChats Spracherkennung. Gibt den
    erkannten Text zurück, oder None, wenn nichts Verwertbares aufgenommen wurde."""
    rec_path = f"/tmp/aura_rec_{int(time.time() * 1000)}"
    agi.record_file(rec_path, max_seconds=RECORD_MAX_SECONDS, silence_seconds=RECORD_SILENCE_SECONDS)
    wav_path = rec_path + ".wav"

    if not os.path.exists(wav_path) or os.path.getsize(wav_path) < 1000:
        return None  # zu kurz/leer, vermutlich nichts gesagt

    with open(wav_path, "rb") as f:
        resp = requests.post(
            f"{AURACHAT_BASE_URL}/api/v1/stt",
            headers={"X-API-Key": AURACHAT_API_KEY},
            files={"file": ("recording.wav", f, "audio/wav")},
            timeout=30
        )
    os.unlink(wav_path)
    if not resp.ok:
        return None
    return (resp.json().get("text") or "").strip()


def ask_aura(text):
    resp = requests.post(
        f"{AURACHAT_BASE_URL}/api/v1/chat",
        headers={"X-API-Key": AURACHAT_API_KEY, "Content-Type": "application/json"},
        json={"message": text}, timeout=60
    )
    resp.raise_for_status()
    return resp.json().get("reply", "")


def main():
    agi = AGI()
    agi.answer()
    agi.verbose("AuraChat-Telefonbruecke gestartet")

    speak(agi, GREETING_TEXT, cache_key="greeting")

    for _ in range(MAX_TURNS):
        heard = listen_and_understand(agi)
        if not heard:
            speak(agi, "Entschuldige, ich habe nichts verstanden. Versuch's nochmal, oder leg auf, wenn du fertig bist.")
            continue

        if any(w in heard.lower() for w in ["auf wiederhören", "tschüss", "das wärs", "das war's", "leg auf"]):
            break

        try:
            reply = ask_aura(heard)
        except Exception:
            speak(agi, "Entschuldige, ich hatte gerade ein Problem. Kannst du das nochmal sagen?")
            continue

        speak(agi, reply)

    speak(agi, GOODBYE_TEXT, cache_key="goodbye")
    agi.hangup()


if __name__ == "__main__":
    main()

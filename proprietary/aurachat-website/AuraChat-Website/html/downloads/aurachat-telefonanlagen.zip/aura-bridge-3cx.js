/*
 * AuraChat <-> 3CX: Call Flow Designer-Skript
 *
 * Läuft IN 3CX selbst (Call Flow Designer, nicht Teil von AuraChat/Docker). Wird als
 * eigener Anruf-Fluss angelegt und einer Nebenstelle/Routing-Regel zugewiesen.
 *
 * WICHTIGER HINWEIS ZUR GENAUIGKEIT DIESER VORLAGE
 * ---------------------------------------------------
 * 3CX' Call-Flow-Designer-API (Methodennamen, genaue Signaturen) unterscheidet sich
 * teils zwischen 3CX-Versionen (v18/v20/...) und wird von 3CX gelegentlich angepasst.
 * Diese Vorlage folgt dem allgemein dokumentierten Grundmuster (Call.Say/Call.PlayFile,
 * Recording, Http-Modul), wurde aber NICHT an einer echten 3CX-Instanz getestet - anders
 * als die Asterisk-Variante, wo das AGI-Protokoll seit Jahren stabil und gut dokumentiert
 * ist. Vor dem produktiven Einsatz unbedingt gegen die aktuelle 3CX Call-Flow-Designer-
 * Dokumentation eurer konkreten Version prüfen und die mit "// PRÜFEN:" markierten
 * Stellen bei Bedarf an die tatsächliche API-Signatur anpassen.
 *
 * Einrichtung
 * -----------
 * 1. 3CX Admin Console -> Call Flow Designer -> neues Skript anlegen, Inhalt dieser
 *    Datei einfügen (oder als .ts-Datei importieren, je nach 3CX-Version).
 * 2. Unten AURACHAT_BASE_URL und AURACHAT_API_KEY eintragen (Schlüssel: AuraChat
 *    Admin Panel -> API -> "API-Schlüssel erzeugen").
 * 3. Das Skript einer Nebenstelle oder Eingangsregel zuweisen (3CX Admin Console ->
 *    entsprechende Route -> "Call Flow Designer"-Skript auswählen).
 * 4. Testanruf auf die zugewiesene Nummer/Nebenstelle.
 */

const AURACHAT_BASE_URL = "https://aurachat.gerber-backoffice-solutions.com"; // eure echte Adresse
const AURACHAT_API_KEY = "HIER-EUREN-API-SCHLUESSEL-EINTRAGEN";
const MAX_TURNS = 12;
const GREETING_TEXT = "Hallo, hier ist Aura. Wie kann ich dir helfen?";
const GOODBYE_TEXT = "Auf Wiederhören!";

// PRÜFEN: In manchen 3CX-Versionen heisst das Einstiegsobjekt anders bzw. wird die
// Callflow-Funktion mit einem anderen Namen/Signatur exportiert - ggf. an das von 3CX
// beim Anlegen des Skripts vorgegebene Gerüst anpassen.
async function OnCallFlowStart(Call) {
    Call.Answer();
    await speak(Call, GREETING_TEXT);

    for (let turn = 0; turn < MAX_TURNS; turn++) {
        const heard = await listenAndUnderstand(Call);

        if (!heard) {
            await speak(Call, "Entschuldige, ich habe nichts verstanden. Versuch's nochmal, oder leg auf, wenn du fertig bist.");
            continue;
        }

        const lower = heard.toLowerCase();
        if (["auf wiederhören", "tschüss", "das wärs", "das war's", "leg auf"].some(w => lower.includes(w))) {
            break;
        }

        let reply;
        try {
            reply = await askAura(heard);
        } catch (err) {
            await speak(Call, "Entschuldige, ich hatte gerade ein Problem. Kannst du das nochmal sagen?");
            continue;
        }
        await speak(Call, reply);
    }

    await speak(Call, GOODBYE_TEXT);
    Call.Hangup();
}

// Holt Sprachausgabe von AuraChat und spielt sie ab.
async function speak(Call, text) {
    const audioBuffer = await Http.Post(
        `${AURACHAT_BASE_URL}/api/v1/tts`,
        { text },
        { headers: { "X-API-Key": AURACHAT_API_KEY, "Content-Type": "application/json" }, responseType: "arraybuffer" }
        // PRÜFEN: Je nach 3CX-Version heisst die Option für Rohdaten-Antworten evtl.
        // anders, oder Http.Post gibt grundsätzlich nur Text/JSON zurück - dann stattdessen
        // Http.Download(...) oder eine vergleichbare Methode für Binärdaten verwenden,
        // falls vorhanden. Die 3CX-Dokumentation zum "Http"-Modul des Call Flow Designer
        // gibt hierzu die verbindliche Antwort für die jeweilige Version.
    );
    // PRÜFEN: 3CX braucht die Audiodatei vermutlich in einem bestimmten Format/Sample-
    // rate (analog zur 8kHz-WAV-Umwandlung bei Asterisk) - falls Call.PlayFile/Call.Say
    // Rohdaten nicht direkt akzeptiert, die Datei zwischenspeichern und im vom Call Flow
    // Designer erwarteten Format referenzieren.
    await Call.PlayFile(audioBuffer);
}

// Nimmt eine Äusserung auf und schickt sie an AuraChats Spracherkennung.
async function listenAndUnderstand(Call) {
    // PRÜFEN: Methodenname/Parameter fürs Aufnehmen mit automatischer Stille-Erkennung
    // variiert zwischen 3CX-Versionen - in der Doku meist unter "Record"/"RecordUtterance"
    // o.ä. zu finden. silenceTimeout/maxDuration-Werte an Bedarf anpassen.
    const recording = await Call.Record({ silenceTimeout: 2000, maxDuration: 15000 });
    if (!recording || recording.length < 1000) return null;

    const result = await Http.Post(
        `${AURACHAT_BASE_URL}/api/v1/stt`,
        recording,
        { headers: { "X-API-Key": AURACHAT_API_KEY }, isMultipartFile: true, fileFieldName: "file" }
        // PRÜFEN: Multipart-Datei-Uploads über das Http-Modul des Call Flow Designer -
        // falls diese Option so nicht existiert, ggf. die Aufnahme erst in einen anderen
        // Objekttyp konvertieren müssen, den das jeweilige Http-Modul für Datei-Uploads
        // erwartet (siehe 3CX-Dokumentation zum "Http"-Modul).
    );
    return (result && result.text) ? result.text.trim() : null;
}

async function askAura(text) {
    const result = await Http.Post(
        `${AURACHAT_BASE_URL}/api/v1/chat`,
        { message: text },
        { headers: { "X-API-Key": AURACHAT_API_KEY, "Content-Type": "application/json" } }
    );
    return result.reply || "";
}

# AuraDirect

Zentrale Benutzerverwaltung für AuraChat, AuraPlan, AuraTicket, AuraMail und AuraProxy, inklusive
Active-Directory-Anbindung und zentraler Zwei-Faktor-Authentifizierung.

## Einrichtung

```bash
cp .env.example .env
```

`.env` öffnen und die Werte ausfüllen (Anleitung steht direkt in der Datei).

```bash
docker compose up -d
```

Danach ist AuraDirect unter `http://<Server-IP>:4000` erreichbar.

Anmeldung: Benutzername `admin`, das Passwort ist das, was ihr unter AURADIRECT_ADMIN_PASSWORD in der
.env-Datei eingetragen habt.

## Aktualisieren

```bash
docker compose pull
docker compose up -d
```

## Mit den Aura-Produkten verbinden

In jedem Produkt im Admin Panel die AuraDirect-Adresse und den Dienst-Schlüssel (Admin Panel von AuraDirect →
Benutzer) eintragen, um die zentrale Anmeldung zu aktivieren. Bei jeder Person in AuraDirect legt man mit
Häkchen fest, welche Produkte sie nutzen darf und mit welcher Rolle.

## Lizenz

AuraDirect ist kostenlos bis 4 Konten oder sobald mindestens zwei Aura-Anwendungen (z.B. AuraChat und
AuraPlan) verbunden sind. Eigenständig genutzt kostet es CHF 15.– pro Installation und Monat.
Lizenzschlüssel und Fragen: info@gerber-backoffice-solutions.com

# AuraTicket

Support-Tickets aus E-Mails, im Team bearbeitet, per E-Mail beantwortet und per AuraChat steuerbar.

## Einrichtung

```bash
cp .env.example .env
```

`.env` öffnen und den Wert ausfüllen (Anleitung steht direkt in der Datei).

```bash
docker compose up -d
```

Danach ist AuraTicket unter `http://<Server-IP>:3400` erreichbar.
Erste Anmeldung: Benutzername `admin`, Passwort `admin` (bitte sofort ändern).

## Mit AuraMail verbinden (für E-Mail-zu-Ticket und Antworten)

1. In **AuraMail** → Admin Panel → Sicherheit → Externe API den Dienst-Schlüssel kopieren.
2. In **AuraTicket** → Admin Panel → AuraMail-Anbindung: AuraMail-Adresse, Dienst-Schlüssel und das
   Support-Postfach (z.B. `support@firma.ch`) eintragen.

Eingehende Mails werden danach etwa alle 3 Minuten zu Tickets. Antworten laufen über AuraMail.

## Zentrale Anmeldung (optional)

Admin Panel → AuraDirect: Adresse und Dienst-Schlüssel eintragen. In AuraDirect bei der Person das
Häkchen "AuraTicket" setzen.

## Steuerung per AuraChat (optional)

In AuraChat unter Admin Panel → API → "AuraTicket verbinden" die Adresse und den Dienst-Schlüssel
(AuraTicket → Admin Panel → Sicherheit → Externe API) eintragen. Danach z.B.: "Wie viele Tickets sind offen?",
"Schliess Ticket T-00001", "Antworte auf Ticket T-00001: ...". Neue Tickets werden vorgelesen.

## Aktualisieren

```bash
docker compose pull
docker compose up -d
```

## Lizenz

AuraTicket ist kostenlos bis 3 Agent:innen und 1 Administrator:in und hat 14 Tage Testphase.
Für mehr Agent:innen und Administrator:innen gibt es Lizenzschlüssel auf Anfrage: info@gerber-backoffice-solutions.com

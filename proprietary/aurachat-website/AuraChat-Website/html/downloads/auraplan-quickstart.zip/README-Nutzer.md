# AuraPlan

Zeiterfassung, Schichtplan und Ferien — eigenständig oder verbunden mit AuraChat.

## Einrichtung

```bash
cp .env.example .env
```

`.env` öffnen und die beiden Werte ausfüllen (Anleitung steht direkt in der Datei).

```bash
docker compose up -d
```

Danach ist AuraPlan unter `http://<Server-IP>:8080` erreichbar (bzw. Port 80,
falls auf einem eigenen Server ohne AuraChat).

Anmeldung: Benutzername `admin`, Passwort `admin` — bitte gleich nach dem
ersten Login unter Menü → Passwort ändern.

## Aktualisieren

```bash
docker compose pull
docker compose up -d
```

## Mit AuraChat verbinden

Im Admin Panel von AuraChat unter "API" → "AuraPlan verbinden" die Adresse
eintragen, damit Zeiterfassung/Ferien per Chat oder Sprachbefehl möglich wird.

## Eigene Domain mit automatischem HTTPS

Im Admin Panel unter "Domain & SSL" eine eigene Domain eintragen — AuraPlan
kümmert sich danach automatisch um ein Let's-Encrypt-Zertifikat.

## Premium-Funktionen

AuraPlan läuft ohne Lizenzschlüssel in einer kostenlosen Basisstufe (einfache
Zeiterfassung). Für alle Funktionen (Schichtplan, Ferien, Übersicht,
Benachrichtigungen) wird ein Lizenzschlüssel benötigt —
Kontakt: info@gerber-backoffice-solutions.com

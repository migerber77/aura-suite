# AuraChat

Selbst gehosteter KI-Chat mit Avatar, Gedächtnis und Sprachsteuerung. Läuft mit eurem eigenen Ollama-Server.
Dieses Paket installiert alles auf einmal: Oberfläche, Server, HTTPS (Caddy), Web-Suche (SearXNG) und Sprache (TTS/STT).

## Einrichtung

```bash
cp .env.example .env
```

`.env` öffnen und die zwei Schlüssel ausfüllen (Anleitung steht direkt in der Datei). Gut aufbewahren: mit
anderen Schlüsseln sind Sitzungen weg und der verschlüsselte "Grund" hinter Auras Verfassung nicht mehr lesbar.

```bash
docker compose up -d
```

Danach ist AuraChat unter `http://<Server-IP>:8091` erreichbar.
Erste Anmeldung: Benutzername `admin`, Passwort `admin` (bitte sofort ändern).

## Alternative mit einem einzigen Befehl (Docker Engine 25 oder neuer)

Ohne dieses Paket, direkt von Docker Hub:

```bash
printf "SESSION_SECRET=%s\nDISPOSITION_ENCRYPTION_KEY=%s\n" "$(openssl rand -hex 32)" "$(openssl rand -hex 32)" > .env
docker compose -p aurachat --env-file .env -f oci://docker.io/migerber77/aurachat:latest up -d
```

## Ollama

Ollama läuft auf eurem eigenen Server. Im Admin Panel von AuraChat die Adresse eintragen.

## HTTPS mit eigener Domain

Im Admin Panel von AuraChat die Domain eintragen. Caddy holt automatisch ein Zertifikat. Dafür müssen die
Ports 80 und 443 frei und aus dem Internet erreichbar sein. Alternativ AuraProxy davorsetzen.

## Aktualisieren

```bash
docker compose pull
docker compose up -d
```

Der Reiter "Backup & Update" im Admin Panel aktualisiert in dieser Variante nichts. Updates laufen über `pull`.

## Premium-Funktionen

Für Premium-Funktionen (eigene Domain mit SSL, Sprache, Bildgenerierung, Coding-Modell u.a.) wird ein
Lizenzschlüssel benötigt. Kontakt: info@gerber-backoffice-solutions.com

# AuraMail

Eigener Mailserver für persönliche und geteilte Postfächer: wahlweise mit eigenem
Mailserver, Microsoft 365 oder bestehenden IMAP/SMTP-Konten.

## Einrichtung

```bash
cp .env.example .env
```

`.env` öffnen und die Werte ausfüllen (Anleitung steht direkt in der Datei).

```bash
docker compose up -d
```

Danach ist AuraMail unter `http://<Server-IP>:3300` erreichbar.
Erste Anmeldung: Benutzername `admin`, Passwort `admin` (bitte sofort ändern).

## Anbindung wählen

Admin Panel → Mail-Anbindung:

- **Eigener Mailserver:** für den Empfang aus dem Internet extern Port 25 auf Port 2525 weiterleiten.
- **Microsoft 365:** Tenant-ID, Client-ID und Client-Secret einer Azure-App-Registrierung eintragen.
  Benötigte Anwendungsberechtigungen: `Mail.Send`, `Mail.Read` und für die Konten-Auswahl `User.Read.All`
  (jeweils mit Administratorzustimmung). Danach im Reiter Postfächer die Konten aus Microsoft 365 auswählen.
- **IMAP/SMTP:** bestehende Konten mit Server und Zugangsdaten eintragen.

## Aktualisieren

```bash
docker compose pull
docker compose up -d
```

## Mit anderen Aura-Produkten verbinden

- **AuraDirect:** Admin Panel → AuraDirect: Adresse und Dienst-Schlüssel eintragen. Danach melden sich
  Personen mit ihrem AuraDirect-Konto an, und "Personen aus AuraDirect übernehmen" legt sie an
  (in AuraDirect muss bei der Person das Häkchen "AuraMail" gesetzt sein).
- **AuraChat und AuraTicket:** Den Dienst-Schlüssel aus AuraMail (Admin Panel → Sicherheit → Externe API)
  im jeweiligen Produkt eintragen.

## Lizenz

AuraMail ist kostenlos bis 4 Konten oder sobald mindestens zwei Aura-Anwendungen (z.B. AuraChat und
AuraPlan) verbunden sind. Eigenständig genutzt kostet es CHF 15.– pro Installation und Monat.
Lizenzschlüssel und Fragen: info@gerber-backoffice-solutions.com

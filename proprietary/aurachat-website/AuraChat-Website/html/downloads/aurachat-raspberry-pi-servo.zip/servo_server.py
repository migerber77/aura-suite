"""
AuraChat - Beispiel: Raspberry-Pi-Servo per HTTP steuern

Läuft DIREKT auf dem Raspberry Pi (nicht in Docker/AuraChat selbst) und stellt
eine kleine HTTP-Schnittstelle bereit, die AuraChat als "Eigenes HTTP-Gerät"
anspricht (Admin Panel -> API -> "Eigene Anwendung/Gerät verbinden").

Einrichtung auf dem Pi
-----------------------
1. Servo an einen GPIO-Pin anschliessen (Standard hier: GPIO17 - unten anpassen,
   falls ein anderer Pin genutzt wird).
2. Abhängigkeiten installieren:
       pip install flask gpiozero --break-system-packages
3. Skript starten (bleibt im Vordergrund laufen, zum Testen reicht das):
       python3 servo_server.py
   Für Dauerbetrieb z.B. als systemd-Service einrichten, siehe README.md daneben.
4. Die IP-Adresse des Pi im lokalen Netz herausfinden:
       hostname -I

Einrichtung in AuraChat (Admin Panel -> API)
----------------------------------------------
Name:          z.B. "Garagentor-Servo"
Basis-URL:     http://<PI-IP>:5000        (Port anpassen, falls unten geändert)
Auth-Header:   leer lassen (dieses Beispiel hat keine Authentifizierung -
               siehe Hinweis zur Absicherung unten im README)

Befehl 1 - fester Winkel:
    Auslöse-Satz:      Servo öffnen
    Methode:           POST
    Pfad:              /servo
    Body:              {"angle": 90}
    Bestätigungstext:  Servo geöffnet.

Befehl 2 - Winkel aus der Nachricht (z.B. "Servo auf 45 Grad stellen"):
    Auslöse-Satz:      Servo auf
    Methode:           POST
    Pfad:              /servo
    Body:              {"angle": {value}}
    Bestätigungstext:  Servo gestellt.

("{value}" wird von AuraChat automatisch durch die erste Zahl aus der
gesprochenen/geschriebenen Nachricht ersetzt.)
"""

from flask import Flask, request, jsonify
from gpiozero import AngularServo

# --- Anpassen an die eigene Verkabelung ---
SERVO_PIN = 17          # GPIO-Pin, an dem der Servo hängt (BCM-Nummerierung)
MIN_ANGLE = 0
MAX_ANGLE = 180
PORT = 5000

servo = AngularServo(
    SERVO_PIN,
    min_angle=MIN_ANGLE,
    max_angle=MAX_ANGLE,
    min_pulse_width=0.0005,   # Standardwerte für die meisten gängigen Servos (SG90 & Co).
    max_pulse_width=0.0025,   # Bei Zittern/falschem Ausschlag hier leicht anpassen.
)

app = Flask(__name__)


@app.route("/servo", methods=["POST"])
def set_servo_angle():
    data = request.get_json(silent=True) or {}
    angle = data.get("angle")

    if angle is None:
        return jsonify({"error": "Feld 'angle' fehlt im Body."}), 400
    try:
        angle = float(angle)
    except (TypeError, ValueError):
        return jsonify({"error": "'angle' muss eine Zahl sein."}), 400

    angle = max(MIN_ANGLE, min(MAX_ANGLE, angle))  # sicherheitshalber auf den erlaubten Bereich begrenzen
    servo.angle = angle

    return jsonify({"success": True, "angle": angle})


@app.route("/status", methods=["GET"])
def status():
    return jsonify({"angle": servo.angle})


if __name__ == "__main__":
    # host="0.0.0.0": von anderen Geräten im Netzwerk (u.a. AuraChat) erreichbar,
    # nicht nur vom Pi selbst.
    app.run(host="0.0.0.0", port=PORT)

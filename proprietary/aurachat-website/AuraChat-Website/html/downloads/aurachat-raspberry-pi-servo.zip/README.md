# AuraChat ↔ Raspberry Pi: Servo-Beispiel

Fertige Vorlage, um einen Servo (oder nach demselben Muster: Relais, LEDs, etc.)
am Raspberry Pi per Sprachbefehl über AuraChat zu steuern. `servo_server.py`
läuft direkt auf dem Pi, AuraChat spricht es ganz normal per HTTP an
(genau wie die eingebaute Sonos-/IKEA-Dirigera-Anbindung).

## Einrichtung

```bash
# Auf dem Raspberry Pi:
pip install flask gpiozero --break-system-packages
python3 servo_server.py
```

Testen, ob's läuft (von einem anderen Gerät im selben Netz):

```bash
curl -X POST http://<PI-IP>:5000/servo -H "Content-Type: application/json" -d '{"angle": 90}'
```

Der Servo sollte sich auf 90° stellen. IP-Adresse des Pi mit `hostname -I` herausfinden.

## Dauerhaft laufen lassen (systemd)

Damit der Server automatisch startet und nach einem Absturz/Neustart wieder hochkommt:

```bash
sudo tee /etc/systemd/system/aurachat-servo.service << 'EOF'
[Unit]
Description=AuraChat Servo-Steuerung
After=network.target

[Service]
ExecStart=/usr/bin/python3 /home/pi/servo_server.py
WorkingDirectory=/home/pi
Restart=always
User=pi

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl enable --now aurachat-servo
```

Pfad (`/home/pi/servo_server.py`) und Benutzer (`User=pi`) bei Bedarf anpassen.

## In AuraChat eintragen

Admin Panel → API → "🔗 Eigene Anwendung/Gerät verbinden":

| Feld | Wert |
|---|---|
| Name | z.B. "Garagentor-Servo" |
| Basis-URL | `http://<PI-IP>:5000` |

Dann unter "Befehle" z.B.:

| Auslöse-Satz | Methode | Pfad | Body | Bestätigungstext |
|---|---|---|---|---|
| Servo öffnen | POST | /servo | `{"angle": 90}` | Servo geöffnet. |
| Servo schliessen | POST | /servo | `{"angle": 0}` | Servo geschlossen. |
| Servo auf | POST | /servo | `{"angle": {value}}` | Servo gestellt. |

Danach im Chat einfach z.B. "Servo öffnen" oder "Stell den Servo auf 45 Grad" sagen.

## ⚠️ Wichtiger Sicherheitshinweis

Dieses Beispiel hat **keine Authentifizierung** - jedes Gerät im selben
Netzwerk könnte den Servo ansteuern, nicht nur AuraChat. Für ein
Heimnetzwerk hinter eurem eigenen Router meist unkritisch, aber:

- Nicht direkt aus dem Internet erreichbar machen (keine Portweiterleitung
  auf Port 5000 einrichten)
- Für sensiblere Anwendungen (z.B. eine Tür, ein Tor): einen einfachen
  API-Key einbauen (`request.headers.get("X-API-Key")` prüfen) und in
  AuraChat unter "Auth-Header"/"Auth-Wert" denselben Wert eintragen

## Eigene Erweiterungen

Das gleiche Muster funktioniert für alles, was sich per Python auf dem Pi
ansteuern lässt - einfach eine weitere Flask-Route nach demselben Vorbild
ergänzen, z.B. für ein Relais:

```python
from gpiozero import OutputDevice
relay = OutputDevice(27)

@app.route("/relay/on", methods=["POST"])
def relay_on():
    relay.on()
    return jsonify({"success": True})

@app.route("/relay/off", methods=["POST"])
def relay_off():
    relay.off()
    return jsonify({"success": True})
```
